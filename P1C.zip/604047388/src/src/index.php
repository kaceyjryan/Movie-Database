<!DOCTYPE html>
<html>
<body>

<h1>Home Page for Movie Database</h1>

<h3>Input Into Database</h3>
<a href="input.php">Add Movies, Actors, Directors, Genres, and Relations</a><br><br>
<a href="review.php">Add Reviews to Movies</a><br><br>

<h3>Browse Database</h3>
<a href="browseA.php">Browse Actors</a><br><br>
<a href="browseM.php">Browse Movies</a><br><br>

<h3>Search Database</h3>
<a href="search.php">Search for Movies and Actors</a><br><br>

</body>
</html>
